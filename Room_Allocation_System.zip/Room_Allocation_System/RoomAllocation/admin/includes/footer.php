<div class="footer">
			<div class="wthree-copyright">
			  <p>© 2020 Room Allocation System. All rights reserved.</p>
			</div>
		  </div>